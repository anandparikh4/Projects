#ifndef _PARSE_H
#define _PARSE_H
#include "process.h"

process *parse(char *line , int * n_proc , int * background);

#endif